<template>
  <div>
    <b-navbar type="is-primary">
      <template slot="brand">
        <b-navbar-item tag="router-link" to="/">
          MyProject
        </b-navbar-item>
      </template>

      <template slot="start">
        <b-navbar-item tag="router-link" to="/create">
          CREA NUOVO TASK
        </b-navbar-item>
      </template>

      <template slot="end">
        <b-navbar-item @click="switchLanguage('IT')" active>
          IT
        </b-navbar-item>
        <b-navbar-item @click="switchLanguage('EN')">
          EN
        </b-navbar-item>
      </template>
    </b-navbar>

    <div class="container column">
      <nuxt />
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    switchLanguage(lang) {}
  }
}
</script>
