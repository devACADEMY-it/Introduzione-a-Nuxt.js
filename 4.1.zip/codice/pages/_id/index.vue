<template>
  <div v-if="item" class="column">
    <h1 class="title">{{ item.title }}</h1>
    <b-taglist attached>
      <b-tag type="is-success" size="is-medium">Stato</b-tag>
      <b-tag type="is-dark" size="is-medium">{{ item.state }}</b-tag>
    </b-taglist>
    <b-taglist attached>
      <b-tag type="is-warning" size="is-medium">Data</b-tag>
      <b-tag type="is-dark" size="is-medium">{{
        new Date(item.date).toLocaleDateString()
      }}</b-tag>
    </b-taglist>
    <hr />
    <section>
      {{ item.description }}
    </section>

    <hr />
    <div class="level">
      <div class="level-left">
        <b-button @click="remove" type="is-danger" icon-left="delete"
          >Elimina</b-button
        >
      </div>
      <div class="level-right">
        <b-button @click="gotoUpdate" type="is-primary" icon-left="pencil">
          Modifica
        </b-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  computed: {
    id() {
      return this.$route.params.id
    },
    item() {
      return this.$store.state.task.detail
    }
  },
  async created() {
    await this.$store.dispatch('task/getTask', this.$route.params.id)
  },
  methods: {
    async remove() {
      await this.$store.dispatch('task/removeTask', this.item)
    },
    gotoUpdate() {
      this.$router.push('/' + this.id + '/update')
    }
  }
}
</script>
