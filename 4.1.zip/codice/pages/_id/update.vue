<template>
  <div v-if="item" class="column">
    <client-only>
      <todo-form v-model="item" :states="states" title="Modifica Task">
        <template v-slot:footer>
          <div class="level">
            <div class="level-left">
              <b-button @click="remove" type="is-danger" icon-left="delete">
                Elimina
              </b-button>
            </div>
            <div class="level-right">
              <b-button
                @click="save"
                type="is-success"
                icon-left="content-save"
              >
                Salva
              </b-button>
            </div>
          </div>
        </template>
      </todo-form>
    </client-only>
  </div>
</template>

<script>
import TodoForm from '../../components/TodoForm'
export default {
  components: { TodoForm },
  data() {
    return {
      item: null
    }
  },
  computed: {
    id() {
      return this.$route.params.id
    },
    states() {
      return this.$store.state.task.states
    }
  },
  async created() {
    await this.$store.dispatch('task/getTask', this.id)
    this.item = this.$store.getters['task/getDetail']
  },
  methods: {
    async remove() {
      await this.$store.dispatch('task/removeTask', this.item)
      this.$router.push('/')
    },
    async save() {
      await this.$store.dispatch('task/saveTask', this.item)
      this.$router.push('/')
    }
  }
}
</script>
