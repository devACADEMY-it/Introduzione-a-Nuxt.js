const taskFromJson = (json) => ({
  ...json,
  date: json.date ? new Date(json.date) : null
})

export const state = () => ({
  list: [],
  detail: null,
  states: [
    {
      id: 'inbox',
      title: 'Inbox',
      icon: 'inbox-arrow-down'
    },
    {
      id: 'next',
      title: 'Next Actions',
      icon: 'checkbox-multiple-marked-outline'
    },
    { id: 'calendar', title: 'Calendar', icon: 'calendar-multiple-check' },
    { id: 'maybe', title: 'Maybe', icon: 'help' },
    { id: 'archive', title: 'Archive', icon: 'archive' }
  ]
})

export const mutations = {
  setList(state, items) {
    state.list = items
  },
  setDetail(state, item) {
    state.detail = item
  },
  updateList(state, item) {
    const index = state.list.findIndex((el) => el.id === item.id)
    if (index !== -1) {
      state.list.splice(index, 1, item)
    }
  }
}

export const actions = {}

export const getters = {}
