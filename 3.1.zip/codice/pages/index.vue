<template>
  <div class="columns is-centered">
    <div
      v-for="state in states"
      :key="state.id"
      class="column has-text-centered"
    >
      <h2>
        <b-icon :icon="state.icon" size="is-small"></b-icon>
        {{ state.title }}
      </h2>
      <card title="Titolo task" description="Descrizione task"></card>
    </div>
  </div>
</template>

<script>
import Card from '../components/Card'

export default {
  name: 'Home',
  components: { Card },
  computed: {
    states() {
      return this.$store.state.task.states
    }
  }
}
</script>
