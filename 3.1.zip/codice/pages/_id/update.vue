<template>
  <div class="column">
    <client-only>
      <todo-form v-model="item" :states="states" title="Modifica Task">
        <template v-slot:footer>
          <div class="level">
            <div class="level-left">
              <b-button @click="remove" type="is-danger" icon-left="delete">
                Elimina
              </b-button>
            </div>
            <div class="level-right">
              <b-button
                @click="save"
                type="is-success"
                icon-left="content-save"
              >
                Salva
              </b-button>
            </div>
          </div>
        </template>
      </todo-form>
    </client-only>
  </div>
</template>

<script>
import TodoForm from '../../components/TodoForm'
export default {
  components: { TodoForm },
  data() {
    return {
      item: {
        title: 'Titolo di prova',
        description: 'Descrizione di prova',
        date: new Date('2017-06-23'),
        state: 'next'
      }
    }
  },
  computed: {
    states() {
      return this.$store.state.task.states
    }
  },
  methods: {
    remove() {
      this.$router.push('/')
    },
    save() {
      this.$router.push('/')
    }
  }
}
</script>
