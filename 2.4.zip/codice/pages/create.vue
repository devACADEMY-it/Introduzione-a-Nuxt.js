<template>
  <h1>CREATE</h1>
</template>

<script>
export default {
  name: 'Create'
}
</script>
