<template>
  <h1>INDEX DETTAGLIO</h1>
</template>
