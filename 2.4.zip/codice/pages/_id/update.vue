<template>
  <h1>UPDATE DETTAGLIO</h1>
</template>
