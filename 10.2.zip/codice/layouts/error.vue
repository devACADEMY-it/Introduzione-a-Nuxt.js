<template>
  <div class="container">
    <h1 v-if="error.statusCode === 404">Pagina non trovata</h1>
    <h1 v-else>Si è verificato un errore</h1>
    <nuxt-link to="/">Home</nuxt-link>
  </div>
</template>

<script>
export default {
  props: {
    error: {
      type: Object,
      default: () => ({})
    }
  }
}
</script>
