export default ({ app }, inject) => {
  inject('debuglog', (string) => console.log('[DEBUG] ' + string))
}
