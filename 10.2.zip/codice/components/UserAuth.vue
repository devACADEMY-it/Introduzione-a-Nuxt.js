<template>
  <form>
    <b-field label="Email">
      <b-input v-model="email" type="email" required></b-input>
    </b-field>
    <b-field label="Password">
      <b-input v-model="password" type="password" required></b-input>
    </b-field>
    <b-button
      @click="onSubmit({ email, password })"
      type="is-success is-outlined"
      >{{ authText }}</b-button
    >
  </form>
</template>

<script>
export default {
  props: {
    onSubmit: {
      type: Function,
      default: () => {}
    },
    authText: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      email: 'nuxtadmin@gmail.com',
      password: 'lol123'
    }
  }
}
</script>
