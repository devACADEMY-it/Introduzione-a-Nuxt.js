<template>
  <h1>Dettaglio {{ $route.params.id }}</h1>
</template>

<script>
export default {}
</script>
