<template>
  <div>
    <h1 class="title">{{ title }}</h1>
    <div class="columns">
      <div class="column">
        <b-field>
          <b-input v-model="value.title"></b-input>
        </b-field>
      </div>
    </div>
    <div class="columns">
      <div class="column">
        <b-field>
          <b-datepicker
            v-model="value.date"
            icon="calendar-today"
          ></b-datepicker>
        </b-field>
      </div>
      <div class="column">
        <b-field>
          <b-select v-model="value.state" expanded>
            <option
              v-for="(state, index) in states"
              :key="index"
              :value="state.id"
              >{{ state.title }}</option
            >
          </b-select>
        </b-field>
      </div>
    </div>
    <div class="columns">
      <div class="column">
        <b-input v-model="value.description" type="textarea"></b-input>
      </div>
    </div>
    <slot name="footer"></slot>
  </div>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: ''
    },
    value: {
      type: Object,
      default: () => ({})
    },
    states: {
      type: Array,
      default: () => []
    }
  }
}
</script>
