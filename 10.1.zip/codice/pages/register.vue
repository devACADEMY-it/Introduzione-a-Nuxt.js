<template>
  <UserAuth :on-submit="register" :auth-text="$t('app.register')"></UserAuth>
</template>

<script>
import UserAuth from '../components/UserAuth'

export default {
  components: { UserAuth },
  auth: false,
  methods: {
    async register(authInfo) {
      // register
    }
  }
}
</script>
