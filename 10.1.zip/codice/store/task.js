const taskFromJson = (json) => ({
  ...json,
  date: json.date ? new Date(json.date) : null
})

export const state = () => ({
  list: [],
  detail: null,
  states: [
    {
      id: 'inbox',
      title: 'Inbox',
      icon: 'inbox-arrow-down'
    },
    {
      id: 'next',
      title: 'Next Actions',
      icon: 'checkbox-multiple-marked-outline'
    },
    { id: 'calendar', title: 'Calendar', icon: 'calendar-multiple-check' },
    { id: 'maybe', title: 'Maybe', icon: 'help' },
    { id: 'archive', title: 'Archive', icon: 'archive' }
  ]
})

export const mutations = {
  setList(state, items) {
    state.list = items
  },
  setDetail(state, item) {
    state.detail = item
  },
  updateList(state, item) {
    const index = state.list.findIndex((el) => el.id === item.id)
    if (index !== -1) {
      state.list.splice(index, 1, item)
    }
  }
}

export const actions = {
  async getTasks(context) {
    const response = await fetch('http://localhost:3000/tasks?_sort=priority')
    const items = (await response.json()).map((item) => taskFromJson(item))
    context.commit('setList', items)
  },
  async getTask(context, id) {
    const response = await fetch(`http://localhost:3000/tasks/${id}`)
    const rawItem = await response.json()
    const item = taskFromJson(rawItem)
    context.commit('setDetail', item)
  },
  async createTask(context, item) {
    const request = await fetch(`http://localhost:3000/tasks/`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item)
    })
    const response = await request.json()
    const newItem = taskFromJson(response)
    context.commit('updateList', newItem)
  },
  async saveTask(context, item) {
    const request = await fetch(`http://localhost:3000/tasks/${item.id}`, {
      method: 'PUT',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item)
    })
    const response = await request.json()
    const newItem = taskFromJson(response)
    context.commit('updateList', newItem)
  },
  async removeTask(context, item) {
    const response = await fetch(`http://localhost:3000/tasks/${item.id}`, {
      method: 'DELETE'
    })
    await response.json()
  },
  async updateTasks(context, taskByState) {
    const toRet = []
    context.state.states.forEach(({ id: state }) => {
      const group = taskByState[state]

      group.forEach((item, priority) => {
        const originalItem = context.state.list.find((el) => el.id === item.id)
        if (originalItem) {
          if (
            originalItem.priority !== priority ||
            originalItem.state !== state
          ) {
            toRet.push({ ...item, priority, state })
          }
        } else {
          toRet.push({ ...item, priority, state })
        }
      })
    })

    toRet.forEach((item) => context.commit('updateList', item))

    const requests = toRet.map((item) => context.dispatch('saveTask', item))
    await Promise.all(requests)
  }
}

export const getters = {
  getTaskByState(state) {
    const toRet = {}

    state.states.forEach(({ id: singleState }) => {
      toRet[singleState] = state.list
        .filter((el) => el.state === singleState)
        .sort((a, b) => {
          return a.priority > b.priority ? 1 : a.priority < b.priority ? -1 : 0
        })
    })

    return toRet
  },
  getDetail(state) {
    return {
      ...state.detail
    }
  }
}
