<template>
  <div class="column">
    <client-only>
      <todo-form v-model="item" :states="states" title="Crea Task">
        <template v-slot:footer>
          <b-button @click="save" type="is-success" icon-left="content-save">
            Crea
          </b-button>
        </template>
      </todo-form>
    </client-only>
  </div>
</template>

<script>
import TodoForm from '../components/TodoForm'
export default {
  name: 'Create',
  components: { TodoForm },
  data() {
    return {
      item: {
        title: '',
        description: '',
        date: new Date(),
        state: 'inbox'
      }
    }
  },
  computed: {
    states() {
      return this.$store.state.task.states
    }
  },
  methods: {
    async save() {
      await this.$store.dispatch('task/saveTask', this.item)
      this.$router.push('/')
    }
  }
}
</script>
