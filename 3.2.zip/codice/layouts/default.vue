<template>
  <div class="container column">
    <nuxt />
  </div>
</template>
