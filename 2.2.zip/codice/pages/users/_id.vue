<template>
  <h1>DETTAGLIO UTENTE {{ $route.params.id }}</h1>
</template>
