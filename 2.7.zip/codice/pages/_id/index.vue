<template>
  <div class="column">
    <h1 class="title">{{ item.title }}</h1>
    <b-taglist attached>
      <b-tag type="is-success" size="is-medium">Stato</b-tag>
      <b-tag type="is-dark" size="is-medium">{{ item.state }}</b-tag>
    </b-taglist>
    <b-taglist attached>
      <b-tag type="is-warning" size="is-medium">Data</b-tag>
      <b-tag type="is-dark" size="is-medium">{{ item.date }}</b-tag>
    </b-taglist>
    <hr />
    <section>
      {{ item.description }}
    </section>

    <hr />
    <div class="level">
      <div class="level-left">
        <b-button type="is-danger" icon-left="delete">Elimina</b-button>
      </div>
      <div class="level-right">
        <b-button type="is-primary" icon-left="pencil" @click="gotoUpdate"
          >Modifica</b-button
        >
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      item: {
        title: 'Titolo 1',
        description: 'Descrizione 1',
        date: new Date().toLocaleDateString(),
        state: 'next'
      }
    }
  },
  computed: {
    id() {
      return this.$route.params.id
    }
  },
  methods: {
    gotoUpdate() {
      this.$router.push('/' + this.id + '/update')
    }
  }
}
</script>
