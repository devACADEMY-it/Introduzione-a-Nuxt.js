<template>
  <div class="columns is-centered">
    <div
      v-for="state in states"
      :key="state.id"
      class="column has-text-centered"
    >
      <h2>
        <b-icon :icon="state.icon" size="is-small"></b-icon>
        {{ state.title }}
      </h2>
      <card title="Titolo task" description="Descrizione task"></card>
    </div>
  </div>
</template>

<script>
import Card from '../components/Card'

export default {
  name: 'Home',
  components: { Card },
  data() {
    return {
      states: [
        {
          id: 'inbox',
          title: 'Inbox',
          icon: 'inbox-arrow-down'
        },
        {
          id: 'next',
          title: 'Next Actions',
          icon: 'checkbox-multiple-marked-outline'
        },
        { id: 'calendar', title: 'Calendar', icon: 'calendar-multiple-check' },
        { id: 'maybe', title: 'Maybe', icon: 'help' },
        { id: 'archive', title: 'Archive', icon: 'archive' }
      ]
    }
  }
}
</script>
