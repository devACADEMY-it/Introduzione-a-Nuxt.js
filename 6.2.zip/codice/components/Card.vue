<template>
  <div class="column">
    <b-tooltip
      :label="description"
      :delay="1000"
      multilined
      animated
      position="is-left"
      type="is-dark"
    >
      <div class="box">
        <article class="media">
          <div class="media-content">
            <div class="content">
              <p>
                <strong>{{ title }}</strong>
              </p>
              <b-taglist>
                <b-tag type="is-warning">{{
                  new Date(date).toLocaleDateString()
                }}</b-tag>
              </b-taglist>
            </div>
          </div>
        </article>
      </div>
    </b-tooltip>
  </div>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: '',
      required: true
    },
    description: {
      type: String,
      default: '',
      required: true
    },
    date: {
      type: Date,
      default: null,
      required: true
    }
  }
}
</script>
