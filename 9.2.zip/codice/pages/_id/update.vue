<template>
  <div class="column">
    <client-only>
      <todo-form v-model="item" :states="states" :title="$t('task.edit')">
        <template v-slot:footer>
          <div class="level">
            <div class="level-left">
              <b-button @click="remove" type="is-danger" icon-left="delete">
                {{ $t('task.remove') }}
              </b-button>
            </div>
            <div class="level-right">
              <b-button
                @click="save"
                type="is-success"
                icon-left="content-save"
              >
                {{ $t('task.edit') }}
              </b-button>
            </div>
          </div>
        </template>
      </todo-form>
    </client-only>
  </div>
</template>

<script>
import TodoForm from '../../components/TodoForm'
export default {
  components: { TodoForm },
  head() {
    return {
      title: `${this.item.title} - ${this.$t('app.edit')}`,
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.item.description
        }
      ]
    }
  },
  computed: {
    states() {
      return this.$store.state.task.states
    }
  },
  async asyncData({ app, store, params: { id } }) {
    app.$debuglog('ASYNC DATA')
    await store.dispatch('task/getTask', id)
    const item = store.getters['task/getDetail']
    return {
      item
    }
  },
  methods: {
    gotoHome() {
      const path = this.$i18n.locale === 'en' ? `/en/` : `/`
      this.$router.push(path)
    },
    async remove() {
      await this.$store.dispatch('task/removeTask', this.item)
      this.gotoHome()
    },
    async save() {
      await this.$store.dispatch('task/saveTask', this.item)
      this.gotoHome()
    }
  }
}
</script>
