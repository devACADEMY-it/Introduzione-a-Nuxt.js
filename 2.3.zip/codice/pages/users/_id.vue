<template>
  <h1>DETTAGLIO UTENTE {{ $route.params.id }}</h1>
</template>

<script>
export default {
  validate({ params }) {
    const id = params.id
    return !isNaN(id) && id.length === 4
  }
}
</script>
