<template>
  <div>
    <ul>
      <li v-for="user in users" :key="user.id">
        <nuxt-link :to="'/users/' + user.id">{{ user.name }}</nuxt-link>
      </li>
    </ul>
    <nuxt-child :key="$route.params.id"></nuxt-child>
  </div>
</template>

<script>
export default {
  data() {
    return {
      users: [
        {
          id: 1,
          name: 'John',
          age: 47
        },
        {
          id: 2,
          name: 'Joe',
          age: 50
        }
      ]
    }
  }
}
</script>
