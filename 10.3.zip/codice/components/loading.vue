<template lang="html">
  <div v-if="loading" class="loading-page">
    <b-notification :closable="false" type="is-info">
      {{ $t('app.loading') }}
    </b-notification>
  </div>
</template>

<script>
export default {
  data: () => ({
    loading: false
  }),
  methods: {
    start() {
      this.loading = true
    },
    finish() {
      this.loading = false
    }
  }
}
</script>

<style scoped>
.loading-page {
  position: fixed;
  top: 400px;
  left: 20%;
  right: 20%;
  width: auto;
  height: auto;
  text-align: center;
  font-size: 30px;
  font-family: sans-serif;
  z-index: 999;
}
</style>
