export default {
  app: {
    title: 'MyProject',
    description: 'A project made with nuxt',
    edit: 'Edit',
    remove: 'Remove',
    cancel: 'Cancel',
    confirm: 'Confirm',
    save: 'Save'
  },
  task: {
    fields: {
      title: 'Title',
      date: 'Date',
      state: 'State',
      description: 'Description'
    },
    states: {
      inbox: 'Inbox',
      next: 'Next Actions',
      calendar: 'Calendar',
      maybe: 'Maybe',
      archive: 'Archive'
    },
    create: 'Create Task',
    creating: 'Creating new task...',
    edit: 'Edit Task',
    sectionName: 'Task',
    state: 'State',
    add: 'Add',
    date: 'Date',
    remove: 'Remove Task',
    removeConfirm: 'Are you sure you want to delete the task {name}?',
    removeDone: 'Task deleted with success!',
    modifyDone: 'Task updated with success!'
  }
}
