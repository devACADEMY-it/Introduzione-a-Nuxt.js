export default () => {
  return new Promise((resolve) =>
    resolve({
      app: {
        title: 'MyProject',
        description: 'Un progetto creato con nuxt',
        all: 'Tutti',
        edit: 'Modifica',
        remove: 'Elimina',
        cancel: 'Annulla',
        confirm: 'Conferma',
        save: 'Salva'
      },
      task: {
        fields: {
          title: 'Titolo',
          date: 'Scadenza',
          state: 'Stato',
          description: 'Descrizione'
        },
        states: {
          inbox: 'Raccolta',
          next: 'Prossime azioni',
          calendar: 'Calendario',
          maybe: 'Forse',
          archive: 'Archivio'
        },
        edit: 'Modifica task',
        sectionName: 'Task',
        state: 'Stato',
        add: 'Aggiungi',
        date: 'Data',
        remove: 'Elimina Task',
        removeConfirm: 'Sei sicuro di voler eliminare il todo {name}?',
        removeDone: 'Todo eliminato con successo!',
        modifyDone: 'Todo modificato con successo!'
      }
    })
  )
}
