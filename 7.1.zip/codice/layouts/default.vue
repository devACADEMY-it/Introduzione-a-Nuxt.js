<template>
  <div>
    <b-navbar type="is-primary">
      <template slot="brand">
        <b-navbar-item tag="router-link" to="/">
          MyProject
        </b-navbar-item>
      </template>

      <template slot="start">
        <b-navbar-item tag="router-link" to="/create">
          CREA NUOVO TASK
        </b-navbar-item>
      </template>

      <template slot="end">
        <b-navbar-item
          v-for="locale in $i18n.locales"
          :key="locale.code"
          :active="locale.code === $i18n.locale"
          @click.native="switchLanguage(locale.code)"
        >
          {{ locale.name }}
        </b-navbar-item>
      </template>
    </b-navbar>

    <div class="container column">
      <nuxt />
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    switchLanguage(langCode) {
      this.$i18n.locale = langCode
    }
  }
}
</script>
