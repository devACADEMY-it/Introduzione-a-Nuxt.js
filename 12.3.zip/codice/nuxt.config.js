export default {
  mode: 'universal',
  pwa: {
    icon: {
      iconSrc: ''
    },
    manifest: {
      name: 'Task Handler'
    }
  },
  router: {
    middleware: 'auth'
  },
  generate: {
    subFolders: false,
    routes: ['/1']
  },
  /*
   ** Headers of the page
   */
  head: {
    title: process.env.npm_package_name || '',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      {
        hid: 'description',
        name: 'description',
        content: process.env.npm_package_description || ''
      }
    ],
    link: [{ rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }]
  },
  /*
   ** Customize the progress-bar color
   */
  loading: '~/components/loading.vue',
  /*
   ** Global CSS
   */
  css: ['~/assets/main.css'],
  /*
   ** Plugins to load before mounting the App
   */
  plugins: [
    {
      src: '~/plugins/debug-log.js',
      mode: 'client'
    }
  ],
  axios: {
    baseURL: 'http://localhost:3000'
  },
  auth: {
    strategies: {
      local: {
        endpoints: {
          login: {
            url: '/login',
            method: 'post',
            propertyName: 'accessToken'
          },
          logout: {
            url: '/logout',
            method: 'post'
          },
          user: {
            url: '/users',
            method: 'get',
            propertyName: false
          }
        }
      }
    }
  },
  /*
   ** Nuxt.js dev-modules
   */
  buildModules: [
    // Doc: https://github.com/nuxt-community/eslint-module
    '@nuxtjs/eslint-module'
  ],
  /*
   ** Nuxt.js modules
   */
  modules: [
    '@nuxtjs/pwa',
    '@nuxtjs/axios',
    '@nuxtjs/auth',
    'nuxt-buefy',
    [
      'nuxt-i18n',
      {
        locales: [
          {
            code: 'en',
            name: 'English',
            file: 'en-US.js'
          },
          {
            code: 'it',
            name: 'Italiano',
            file: 'it-IT.js'
          }
        ],
        lazy: true,
        defaultLocale: 'it',
        langDir: 'assets/locales/',
        vueI18n: {
          fallbackLocale: 'en',
          dateTimeFormats: {
            it: {
              short: {
                year: 'numeric',
                month: 'numeric',
                day: 'numeric'
              },
              long: {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                weekday: 'short',
                hour: 'numeric',
                minute: 'numeric'
              }
            },
            en: {
              short: {
                year: 'numeric',
                month: 'numeric',
                day: 'numeric'
              },
              long: {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                weekday: 'short',
                hour: 'numeric',
                minute: 'numeric'
              }
            }
          }
        }
      }
    ]
  ],
  server: {
    port: 8081
  },
  /*
   ** Build configuration
   */
  build: {
    /*
     ** You can extend webpack config here
     */
    extend(config, ctx) {}
  }
}
