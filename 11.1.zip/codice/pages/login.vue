<template>
  <UserAuth :on-submit="login" :auth-text="$t('app.login')"></UserAuth>
</template>

<script>
import UserAuth from '../components/UserAuth'

export default {
  components: { UserAuth },
  methods: {
    login(authInfo) {
      // login
      this.$auth.loginWith('local', {
        data: authInfo
      })
    }
  }
}
</script>
