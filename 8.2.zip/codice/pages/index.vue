<template>
  <div>
    <div class="columns is-centered">
      <div
        v-for="state in states"
        :key="state.id"
        class="column has-text-centered taskList"
      >
        <h2>
          <b-icon :icon="state.icon" size="is-small"></b-icon>
          {{ $t(`task.states.${state.id}`) }}
        </h2>
        <draggable
          :value="taskByState[state.id]"
          @input="updateTasks($event, state.id)"
          group="tasks"
          class="dropArea"
        >
          <card
            v-for="item in taskByState[state.id]"
            :key="item.id"
            :title="item.title"
            :description="item.description"
            :date="item.date"
            @click="gotoDetail(item.id)"
            class="task-preview"
          ></card>
        </draggable>
        <b-tooltip
          :delay="1000"
          :label="$t('task.add')"
          animated
          position="is-left"
        >
          <b-button
            @click="gotoNew"
            type="is-primary"
            class="hoverPlus"
            icon-right="plus"
          ></b-button>
        </b-tooltip>
      </div>
    </div>
  </div>
</template>

<script>
import Draggable from 'vuedraggable'
import Card from '../components/Card'

export default {
  name: 'Home',
  components: { Card, Draggable },
  head() {
    return {
      title: this.$t('app.title'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: 'Progetto con nuxt'
        }
      ]
    }
  },
  computed: {
    states() {
      return this.$store.state.task.states
    },
    taskByState() {
      return this.$store.getters['task/getTaskByState']
    }
  },
  async fetch({ store }) {
    await store.dispatch('task/getTasks')
  },
  mounted() {
    this.$nextTick(() => {
      this.$nuxt.$loading.start()

      setTimeout(() => this.$nuxt.$loading.finish(), 5000)
    })
  },
  methods: {
    async updateTasks(currentItems, state) {
      await this.$store.dispatch('task/updateTasks', {
        ...this.taskByState,
        [state]: currentItems
      })
    },
    gotoNew() {
      const path = this.$i18n.locale === 'en' ? `/en/create` : `/create`
      this.$router.push(path)
    },
    gotoDetail(id) {
      const path = this.$i18n.locale === 'en' ? `/en/${id}/` : `/${id}/`
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
.hoverPlus {
  display: none;
}
.task-preview {
  cursor: pointer;
}
.taskList:hover .hoverPlus {
  display: inline;
}
.dropArea {
  min-height: 200px;
}
</style>
