<template>
  <div class="column">
    <todo-form v-model="item" title="Crea Task" :states="states">
      <template v-slot:footer>
        <b-button type="is-success" icon-left="content-save" @click="save">
          Crea
        </b-button>
      </template>
    </todo-form>
  </div>
</template>

<script>
import TodoForm from '../components/TodoForm'
export default {
  name: 'Create',
  components: { TodoForm },
  data() {
    return {
      item: {
        title: '',
        description: '',
        date: new Date(),
        state: 'inbox'
      },
      states: [
        {
          id: 'inbox',
          title: 'Inbox',
          icon: 'inbox-arrow-down'
        },
        {
          id: 'next',
          title: 'Next Actions',
          icon: 'checkbox-multiple-marked-outline'
        },
        { id: 'calendar', title: 'Calendar', icon: 'calendar-multiple-check' },
        { id: 'maybe', title: 'Maybe', icon: 'help' },
        { id: 'archive', title: 'Archive', icon: 'archive' }
      ]
    }
  },
  methods: {
    save() {
      this.$router.push('/')
    }
  }
}
</script>
