<template>
  <div class="column">
    <todo-form v-model="item" title="Modifica Task" :states="states">
      <template v-slot:footer>
        <div class="level">
          <div class="level-left">
            <b-button type="is-danger" icon-left="delete" @click="remove">
              Elimina
            </b-button>
          </div>
          <div class="level-right">
            <b-button type="is-success" icon-left="content-save" @click="save">
              Salva
            </b-button>
          </div>
        </div>
      </template>
    </todo-form>
  </div>
</template>

<script>
import TodoForm from '../../components/TodoForm'
export default {
  components: { TodoForm },
  data() {
    return {
      item: {
        title: 'Titolo di prova',
        description: 'Descrizione di prova',
        date: new Date('2017-06-23'),
        state: 'next'
      },
      states: [
        {
          id: 'inbox',
          title: 'Inbox',
          icon: 'inbox-arrow-down'
        },
        {
          id: 'next',
          title: 'Next Actions',
          icon: 'checkbox-multiple-marked-outline'
        },
        { id: 'calendar', title: 'Calendar', icon: 'calendar-multiple-check' },
        { id: 'maybe', title: 'Maybe', icon: 'help' },
        { id: 'archive', title: 'Archive', icon: 'archive' }
      ]
    }
  },
  methods: {
    remove() {
      this.$router.push('/')
    },
    save() {
      this.$router.push('/')
    }
  }
}
</script>
