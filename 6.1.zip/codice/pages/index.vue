<template>
  <div class="columns is-centered">
    <div
      v-for="state in states"
      :key="state.id"
      class="column has-text-centered taskList"
    >
      <h2>
        <b-icon :icon="state.icon" size="is-small"></b-icon>
        {{ state.title }}
      </h2>
      <card
        v-for="item in taskByState[state.id]"
        :key="item.id"
        :title="item.title"
        :description="item.description"
        :date="item.date"
        @click="gotoDetail(item.id)"
        class="task-preview"
      ></card>
      <b-tooltip :delay="1000" label="Aggiungi" animated position="is-left">
        <b-button
          @click="gotoNew"
          type="is-primary"
          class="hoverPlus"
          icon-right="plus"
        ></b-button>
      </b-tooltip>
    </div>
  </div>
</template>

<script>
import Card from '../components/Card'

export default {
  name: 'Home',
  components: { Card },
  head() {
    return {
      title: 'MyProject',
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: 'Progetto con nuxt'
        }
      ]
    }
  },
  computed: {
    states() {
      return this.$store.state.task.states
    },
    taskByState() {
      return this.$store.getters['task/getTaskByState']
    }
  },
  async fetch({ store }) {
    await store.dispatch('task/getTasks')
  },
  methods: {
    gotoNew() {
      this.$router.push('/create')
    },
    gotoDetail(id) {
      this.$router.push('/' + id + '/index')
    }
  }
}
</script>

<style scoped>
.hoverPlus {
  display: none;
}
.task-preview {
  cursor: pointer;
}
.taskList:hover .hoverPlus {
  display: inline;
}
</style>
