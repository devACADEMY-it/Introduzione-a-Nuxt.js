<template>
  <div>
    <b-navbar type="is-primary">
      <template slot="brand">
        <img src="/nuxt.png" style="width: 50px; height: auto;" />
        <!--
        <b-navbar-item @click="gotoHome">
          {{ $t('app.title') }}
        </b-navbar-item>
        -->
      </template>

      <template slot="start">
        <b-navbar-item :to="localePath('create')" tag="router-link">
          {{ $t('task.add') }}
        </b-navbar-item>
      </template>

      <template slot="end">
        <b-navbar-item
          v-for="locale in $i18n.locales"
          :key="locale.code"
          :active="locale.code === $i18n.locale"
          :to="switchLocalePath(locale.code)"
          tag="router-link"
        >
          {{ locale.name }}
        </b-navbar-item>
      </template>
    </b-navbar>

    <div class="container column">
      <nuxt />
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    gotoHome() {
      const path = this.$i18n.locale === 'en' ? `/en/` : `/`
      this.$router.push(path)
    }
  }
}
</script>
