const isLoggedIn = true

export default function(context) {
  if (!isLoggedIn) {
    context.redirect('/')
  }
}
